package filieio;

import java.io.Serializable;

public class Department implements Serializable  {

}
