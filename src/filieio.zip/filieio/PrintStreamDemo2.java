package filieio;

public class PrintStreamDemo2 {

	public static void main(String[] args) {
		
		PrintStreamDemo.myout.println("This is using MY OWN stream");
		System.out.println("This is usiing default stream");
		
	}

}
