
We are exploring java.util package. Below are some Imp classes

1. ArrayList

Array: Static, cannot change the size in runtime
Vs
ArrayList: Dynamic, can grow or shrink in size, insert/update/delete values in between
			ArrayList is  a class. It has its own methods. Any action or any task we need to perform, we need to call the methods

2. HashMap
3. Iterator

4.HashSet
5.HashTable 
6.Vector
